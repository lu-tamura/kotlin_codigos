package com.example.myapplication

class Conteudo_textos {
}